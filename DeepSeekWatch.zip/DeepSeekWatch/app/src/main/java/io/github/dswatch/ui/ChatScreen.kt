package io.github.dswatch.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.ScalingLazyColumnDefaults
import androidx.wear.compose.foundation.lazy.ScalingLazyListAnchorType
import androidx.wear.compose.foundation.lazy.items
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.CircularProgressIndicator
import androidx.wear.compose.material.CompactChip
import androidx.wear.compose.material.ListHeader
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.PositionIndicator
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.TimeText
import androidx.wear.compose.material.Vignette
import androidx.wear.compose.material.VignettePosition
import io.github.dswatch.AppSettings
import io.github.dswatch.ChatState
import io.github.dswatch.ChatViewModel
import io.github.dswatch.Msg
import io.github.dswatch.TextUtil

/** Строка ленты: вопрос целиком или один абзац ответа. */
private data class ChatRow(val key: String, val text: String, val isUser: Boolean)

private fun buildRows(messages: List<Msg>): List<ChatRow> {
    val rows = mutableListOf<ChatRow>()
    messages.forEachIndexed { i, m ->
        when (m.role) {
            "user" -> rows += ChatRow("u$i", m.content, isUser = true)
            "assistant" -> TextUtil.splitParagraphs(m.content).forEachIndexed { p, text ->
                rows += ChatRow("a${i}_$p", text, isUser = false)
            }
        }
    }
    return rows
}

@Composable
fun ChatScreen(
    vm: ChatViewModel,
    state: ChatState,
    settings: AppSettings,
    onOpenSettings: () -> Unit,
) {
    val listState = rememberScalingLazyListState()
    val askText = rememberTextInput { vm.send(it) }
    val askVoice = rememberVoiceInput(
        onResult = { vm.send(it) },
        onUnavailable = { askText("Ваш вопрос") },
    )

    val rows = remember(state.messages) { buildRows(state.messages) }
    val lastAnswer = state.messages.lastOrNull()?.takeIf { it.role == "assistant" && it.content.isNotBlank() }

    // После отправки вопроса прокручиваем так, чтобы он оказался вверху экрана,
    // а ответ печатался под ним.
    val userCount = state.messages.count { it.role == "user" }
    val density = LocalDensity.current
    val screenH = LocalConfiguration.current.screenHeightDp
    LaunchedEffect(userCount) {
        val idx = rows.indexOfLast { it.isUser }
        if (idx >= 0) {
            val offsetPx = with(density) { (screenH / 2 - 44).coerceAtLeast(0).dp.roundToPx() }
            listState.animateScrollToItem(index = idx + 1, scrollOffset = offsetPx)   // +1 — заголовок
        }
    }

    Scaffold(
        timeText = { TimeText() },
        vignette = { Vignette(vignettePosition = VignettePosition.TopAndBottom) },
        positionIndicator = { PositionIndicator(scalingLazyListState = listState) },
    ) {
        ScalingLazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            anchorType = ScalingLazyListAnchorType.ItemStart,
            scalingParams = ScalingLazyColumnDefaults.scalingParams(edgeScale = 0.85f, edgeAlpha = 0.5f),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            item(key = "header") {
                ListHeader { Text("DeepSeek", color = MaterialTheme.colors.primary) }
            }

            if (rows.isEmpty() && !state.generating) {
                item(key = "hint") {
                    Text(
                        text = "Задайте вопрос голосом или с клавиатуры",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.caption1,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            items(rows, key = { it.key }) { row ->
                Bubble(row, settings.fontSize)
            }

            if (state.generating && lastAnswer == null) {
                item(key = "thinking") {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (state.reasoningChars > 0) "Размышляю… ${state.reasoningChars}" else "Думаю…",
                            style = MaterialTheme.typography.caption1,
                        )
                    }
                }
            }

            state.error?.let { err ->
                item(key = "error") {
                    Text(
                        text = err,
                        color = MaterialTheme.colors.error,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.caption1,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (!state.generating && state.messages.lastOrNull()?.role == "user") {
                    item(key = "retry") {
                        CompactChip(onClick = { vm.retry() }, label = { Text("Повторить") })
                    }
                }
            }

            if (state.generating) {
                item(key = "stop") {
                    CompactChip(
                        onClick = { vm.stop() },
                        label = { Text("■ Стоп") },
                        colors = ChipDefaults.secondaryChipColors(),
                    )
                }
            } else {
                if (lastAnswer != null) {
                    item(key = "speak") {
                        CompactChip(
                            onClick = { if (state.speaking) vm.stopSpeaking() else vm.speak(lastAnswer.content) },
                            label = { Text(if (state.speaking) "■ Тише" else "🔊 Озвучить") },
                            colors = ChipDefaults.secondaryChipColors(),
                        )
                    }
                }
                item(key = "voice") {
                    Chip(
                        onClick = askVoice,
                        label = { Text(if (rows.isEmpty()) "Спросить голосом" else "Ещё вопрос голосом") },
                        icon = { Text("🎤") },
                        colors = ChipDefaults.primaryChipColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item(key = "keyboard") {
                    Chip(
                        onClick = { askText("Ваш вопрос") },
                        label = { Text("Ввести текст") },
                        icon = { Text("⌨") },
                        colors = ChipDefaults.secondaryChipColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (state.messages.isNotEmpty()) {
                    item(key = "new") {
                        Chip(
                            onClick = { vm.newChat() },
                            label = { Text("Новый чат") },
                            icon = { Text("✚") },
                            colors = ChipDefaults.secondaryChipColors(),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                item(key = "settings") {
                    Chip(
                        onClick = onOpenSettings,
                        label = { Text("Настройки") },
                        secondaryLabel = { Text(settings.model, maxLines = 1) },
                        icon = { Text("⚙") },
                        colors = ChipDefaults.secondaryChipColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

@Composable
private fun Bubble(row: ChatRow, fontSize: Int) {
    if (row.isUser) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp),
            contentAlignment = Alignment.CenterEnd,
        ) {
            Text(
                text = row.text,
                fontSize = fontSize.sp,
                color = MaterialTheme.colors.onPrimary,
                modifier = Modifier
                    .background(MaterialTheme.colors.primary, RoundedCornerShape(14.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }
    } else {
        Text(
            text = row.text,
            fontSize = fontSize.sp,
            lineHeight = (fontSize + 4).sp,
            color = MaterialTheme.colors.onSurface,
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colors.surface, RoundedCornerShape(14.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
        )
    }
}
