package io.github.dswatch

/** Упрощение Markdown для маленького экрана и для синтеза речи. */
object TextUtil {

    private val fence = Regex("```[A-Za-z0-9_+\\-]*\\n?")
    private val bold = Regex("\\*\\*(.+?)\\*\\*")
    private val boldU = Regex("__(.+?)__")
    private val code = Regex("`([^`\\n]+)`")
    private val heading = Regex("(?m)^#{1,6}\\s+")
    private val bullet = Regex("(?m)^\\s*[-*+]\\s+")
    private val rule = Regex("(?m)^\\s*(-{3,}|\\*{3,}|_{3,})\\s*$")
    private val latexInline = Regex("\\\\\\((.+?)\\\\\\)")
    private val paragraphs = Regex("\\n\\s*\\n")

    fun clean(s: String): String = s
        .replace(fence, "")
        .replace(bold, "\$1")
        .replace(boldU, "\$1")
        .replace(code, "\$1")
        .replace(heading, "")
        .replace(bullet, "• ")
        .replace(rule, "")
        .replace(latexInline, "\$1")
        .trim()

    /** Делим длинный ответ на абзацы — так список на круглом экране прокручивается плавнее. */
    fun splitParagraphs(s: String): List<String> =
        clean(s).split(paragraphs).map { it.trim() }.filter { it.isNotEmpty() }

    /** Разбивка текста на куски для TextToSpeech (у движка есть предел длины). */
    fun chunksForSpeech(s: String, max: Int = 1500): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        for (sentence in s.split(Regex("(?<=[.!?…])\\s+|\\n+"))) {
            if (sentence.isBlank()) continue
            if (sb.length + sentence.length + 1 > max && sb.isNotEmpty()) {
                out += sb.toString()
                sb.clear()
            }
            if (sentence.length > max) {
                sentence.chunked(max).forEach { out += it }
            } else {
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(sentence)
            }
        }
        if (sb.isNotEmpty()) out += sb.toString()
        return out
    }
}
