package io.github.dswatch

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/** Понятная пользователю ошибка. */
class ApiException(message: String) : Exception(message)

/**
 * Клиент OpenAI-совместимого API DeepSeek с потоковой выдачей (SSE).
 * POST https://api.deepseek.com/chat/completions
 */
class DeepSeekClient {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)   // режим размышления может молчать долго
        .writeTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    @Volatile
    private var currentCall: Call? = null

    /** Прервать текущий запрос (кнопка «Стоп»). */
    fun cancel() {
        currentCall?.cancel()
    }

    /**
     * Отправляет диалог и вызывает [onReasoning] / [onContent] для каждого
     * пришедшего фрагмента. Возвращается, когда ответ полностью получен.
     */
    suspend fun stream(
        apiKey: String,
        model: String,
        thinking: Boolean,
        messages: List<Msg>,
        onReasoning: (String) -> Unit,
        onContent: (String) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("model", model)
            put("stream", true)
            put("thinking", JSONObject().put("type", if (thinking) "enabled" else "disabled"))
            put("messages", JSONArray().apply {
                messages.forEach { put(JSONObject().put("role", it.role).put("content", it.content)) }
            })
        }

        val request = Request.Builder()
            .url(ENDPOINT)
            .header("Authorization", "Bearer $apiKey")
            .header("Accept", "text/event-stream")
            .post(body.toString().toRequestBody(JSON))
            .build()

        val call = http.newCall(request)
        currentCall = call
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val raw = resp.body?.string().orEmpty()
                    throw ApiException(httpError(resp.code, raw))
                }
                val source = resp.body?.source() ?: throw ApiException("Пустой ответ сервера")
                while (true) {
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue      // пропускаем ": keep-alive" и пустые строки
                    val data = line.substring(5).trim()
                    if (data == "[DONE]") break
                    if (data.isEmpty()) continue

                    val obj = try { JSONObject(data) } catch (e: Exception) { continue }
                    val choices = obj.optJSONArray("choices") ?: continue
                    if (choices.length() == 0) continue
                    val delta = choices.getJSONObject(0).optJSONObject("delta") ?: continue

                    val reasoning = delta.str("reasoning_content")
                    if (reasoning.isNotEmpty()) onReasoning(reasoning)
                    val content = delta.str("content")
                    if (content.isNotEmpty()) onContent(content)
                }
            }
        } catch (e: ApiException) {
            throw e
        } catch (e: UnknownHostException) {
            throw ApiException("Нет подключения к интернету. Проверьте Wi‑Fi или связь с телефоном.")
        } catch (e: SocketTimeoutException) {
            throw ApiException("Сервер не отвечает. Попробуйте ещё раз.")
        } catch (e: IOException) {
            if (call.isCanceled()) throw e
            throw ApiException("Ошибка сети: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            if (currentCall === call) currentCall = null
        }
    }

    private fun httpError(code: Int, raw: String): String {
        val serverMsg = try {
            JSONObject(raw).optJSONObject("error")?.str("message").orEmpty()
        } catch (e: Exception) {
            ""
        }
        val text = when (code) {
            400 -> "Некорректный запрос (проверьте имя модели в настройках)."
            401 -> "Неверный ключ API. Задайте ключ в настройках."
            402 -> "На балансе DeepSeek закончились средства."
            422 -> "Неверные параметры запроса."
            429 -> "Слишком много запросов. Подождите немного."
            500, 502, 503 -> "Сервер DeepSeek перегружен. Попробуйте позже."
            else -> "Ошибка сервера: HTTP $code."
        }
        return if (serverMsg.isNotBlank()) "$text\n$serverMsg" else text
    }

    companion object {
        private const val ENDPOINT = "https://api.deepseek.com/chat/completions"
        private val JSON = "application/json; charset=utf-8".toMediaType()
    }
}

/** optString возвращает "null" для JSON null — здесь вместо этого пустая строка. */
private fun JSONObject.str(key: String): String =
    if (!has(key) || isNull(key)) "" else optString(key, "")
