package io.github.dswatch

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.wear.compose.material.Colors
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.navigation.SwipeDismissableNavHost
import androidx.wear.compose.navigation.composable
import androidx.wear.compose.navigation.rememberSwipeDismissableNavController
import io.github.dswatch.ui.ChatScreen
import io.github.dswatch.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    private val vm: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent { App(vm, this) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /**
     * Ключ можно передать с компьютера, не набирая его на часах:
     * adb shell am start -n io.github.dswatch/.MainActivity --es api_key sk-...
     */
    private fun handleIntent(intent: Intent?) {
        val key = intent?.getStringExtra("api_key")?.trim().orEmpty()
        if (key.isNotEmpty()) {
            vm.settings.setApiKey(key)
            intent?.removeExtra("api_key")
            Toast.makeText(this, "Ключ API сохранён", Toast.LENGTH_SHORT).show()
        }
    }

    fun keepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}

private val WatchColors = Colors(
    primary = Color(0xFF7B93FF),
    primaryVariant = Color(0xFF4D6BFE),
    secondary = Color(0xFF9FB2FF),
    onPrimary = Color(0xFF0A1440),
    surface = Color(0xFF202124),
    onSurface = Color(0xFFECEEF5),
)

@Composable
private fun App(vm: ChatViewModel, activity: MainActivity) {
    val state by vm.state.collectAsStateWithLifecycle()
    val settings by vm.settings.flow.collectAsStateWithLifecycle()

    // Пока идёт ответ — экран не гаснет
    DisposableEffect(state.generating) {
        activity.keepScreenOn(state.generating)
        onDispose { }
    }

    MaterialTheme(colors = WatchColors) {
        val nav = rememberSwipeDismissableNavController()
        SwipeDismissableNavHost(navController = nav, startDestination = "chat") {
            composable("chat") {
                ChatScreen(
                    vm = vm,
                    state = state,
                    settings = settings,
                    onOpenSettings = { nav.navigate("settings") },
                )
            }
            composable("settings") {
                SettingsScreen(
                    vm = vm,
                    settings = settings,
                    onBack = { nav.popBackStack() },
                )
            }
        }
    }
}
