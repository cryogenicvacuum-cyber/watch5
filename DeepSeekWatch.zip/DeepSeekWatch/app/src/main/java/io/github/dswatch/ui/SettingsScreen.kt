package io.github.dswatch.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.ListHeader
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.PositionIndicator
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.Switch
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.TimeText
import androidx.wear.compose.material.ToggleChip
import io.github.dswatch.AppSettings
import io.github.dswatch.BuildConfig
import io.github.dswatch.ChatViewModel
import io.github.dswatch.SettingsStore

private fun maskKey(key: String): String = when {
    key.isBlank() -> "не задан"
    key.length <= 8 -> "••••"
    else -> key.take(3) + "…" + key.takeLast(4)
}

@Composable
fun SettingsScreen(vm: ChatViewModel, settings: AppSettings, onBack: () -> Unit) {
    val store = vm.settings
    val listState = rememberScalingLazyListState()

    val inputKey = rememberTextInput { store.setApiKey(it.replace(" ", "")) }
    val inputModel = rememberTextInput { store.setModel(it.replace(" ", "")) }
    val inputPrompt = rememberTextInput { store.setSystemPrompt(it) }

    Scaffold(
        timeText = { TimeText() },
        positionIndicator = { PositionIndicator(scalingLazyListState = listState) },
    ) {
        ScalingLazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            item { ListHeader { Text("Настройки") } }

            item {
                Chip(
                    onClick = { inputKey("Ключ API DeepSeek") },
                    label = { Text("Ключ API") },
                    secondaryLabel = { Text(maskKey(settings.apiKey)) },
                    colors = if (settings.apiKey.isBlank()) ChipDefaults.primaryChipColors()
                    else ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            item {
                Chip(
                    onClick = { store.cycleModel() },
                    label = { Text("Модель") },
                    secondaryLabel = { Text(settings.model, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    colors = ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            item {
                Chip(
                    onClick = { inputModel("Имя модели API") },
                    label = { Text("Своя модель…") },
                    colors = ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            item {
                ToggleChip(
                    checked = settings.thinking,
                    onCheckedChange = { store.setThinking(it) },
                    label = { Text("Размышление") },
                    secondaryLabel = { Text(if (settings.thinking) "точнее, но дольше" else "быстрые ответы") },
                    toggleControl = { Switch(checked = settings.thinking) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            item {
                Chip(
                    onClick = { store.cycleFontSize() },
                    label = { Text("Размер шрифта") },
                    secondaryLabel = { Text("${settings.fontSize} sp") },
                    colors = ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            item {
                Chip(
                    onClick = { inputPrompt("Инструкция для модели") },
                    label = { Text("Системная подсказка") },
                    secondaryLabel = {
                        Text(settings.systemPrompt.ifBlank { "нет" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    colors = ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            if (settings.systemPrompt != SettingsStore.DEFAULT_SYSTEM_PROMPT) {
                item {
                    Chip(
                        onClick = { store.setSystemPrompt(SettingsStore.DEFAULT_SYSTEM_PROMPT) },
                        label = { Text("Вернуть подсказку") },
                        colors = ChipDefaults.secondaryChipColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            item {
                Chip(
                    onClick = {
                        vm.newChat()
                        onBack()
                    },
                    label = { Text("Очистить историю") },
                    colors = ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            item {
                Text(
                    text = "Неофициальный клиент API DeepSeek\nверсия ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.caption3,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
