package io.github.dswatch

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Одно сообщение диалога: role = "user" | "assistant" | "system". */
data class Msg(val role: String, val content: String)

data class AppSettings(
    val apiKey: String,
    val model: String,
    val thinking: Boolean,
    val systemPrompt: String,
    val fontSize: Int,
)

/** Настройки и история хранятся в SharedPreferences на часах. */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("dswatch", Context.MODE_PRIVATE)

    private val _flow = MutableStateFlow(load())
    val flow: StateFlow<AppSettings> = _flow.asStateFlow()
    val current: AppSettings get() = _flow.value

    private fun load() = AppSettings(
        apiKey = prefs.getString(K_KEY, null) ?: BuildConfig.DEFAULT_API_KEY,
        model = prefs.getString(K_MODEL, null) ?: MODELS.first(),
        thinking = prefs.getBoolean(K_THINK, false),
        systemPrompt = prefs.getString(K_SYSTEM, null) ?: DEFAULT_SYSTEM_PROMPT,
        fontSize = prefs.getInt(K_FONT, FONT_SIZES[1]),
    )

    fun setApiKey(v: String) = save { putString(K_KEY, v.trim()) }
    fun setModel(v: String) = save { putString(K_MODEL, v.trim()) }
    fun setThinking(v: Boolean) = save { putBoolean(K_THINK, v) }
    fun setSystemPrompt(v: String) = save { putString(K_SYSTEM, v.trim()) }
    fun setFontSize(v: Int) = save { putInt(K_FONT, v) }

    /** Следующая модель из списка готовых (по кругу). */
    fun cycleModel() {
        val i = MODELS.indexOf(current.model)
        setModel(MODELS[(i + 1).mod(MODELS.size)])
    }

    fun cycleFontSize() {
        val i = FONT_SIZES.indexOf(current.fontSize)
        setFontSize(FONT_SIZES[(i + 1).mod(FONT_SIZES.size)])
    }

    private inline fun save(block: android.content.SharedPreferences.Editor.() -> Unit) {
        prefs.edit().apply(block).apply()
        _flow.value = load()
    }

    // ---------- история диалога ----------

    fun loadHistory(): List<Msg> = try {
        val arr = JSONArray(prefs.getString(K_HISTORY, "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Msg(o.getString("r"), o.getString("c"))
        }.filter { it.content.isNotBlank() }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveHistory(messages: List<Msg>) {
        val arr = JSONArray()
        messages.filter { it.content.isNotBlank() }
            .takeLast(MAX_SAVED)
            .forEach { arr.put(JSONObject().put("r", it.role).put("c", it.content)) }
        prefs.edit().putString(K_HISTORY, arr.toString()).apply()
    }

    companion object {
        /** Актуальные имена моделей API DeepSeek (октябрь 2026). Можно ввести и своё. */
        val MODELS = listOf("deepseek-flash", "deepseek-v4-pro")
        val FONT_SIZES = listOf(13, 15, 17, 19)

        const val DEFAULT_SYSTEM_PROMPT =
            "Ты помощник на экране умных часов. Отвечай по-русски, кратко и по существу: " +
                "обычно 2–5 предложений. Не используй Markdown, таблицы и длинные списки."

        private const val MAX_SAVED = 60
        private const val K_KEY = "api_key"
        private const val K_MODEL = "model"
        private const val K_THINK = "thinking"
        private const val K_SYSTEM = "system_prompt"
        private const val K_FONT = "font_size"
        private const val K_HISTORY = "history"
    }
}
