package io.github.dswatch

import android.app.Application
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

data class ChatState(
    val messages: List<Msg> = emptyList(),
    val generating: Boolean = false,
    val reasoningChars: Int = 0,
    val error: String? = null,
    val speaking: Boolean = false,
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    val settings = SettingsStore(app)
    private val client = DeepSeekClient()

    private val _state = MutableStateFlow(ChatState(messages = settings.loadHistory()))
    val state: StateFlow<ChatState> = _state.asStateFlow()

    private var job: Job? = null
    @Volatile private var stoppedByUser = false
    @Volatile private var genId = 0   // номер текущего запроса: старые запросы не трогают новый диалог

    // ---------- диалог ----------

    fun send(text: String) {
        val q = text.trim()
        if (q.isEmpty() || _state.value.generating) return
        stopSpeaking()
        val history = _state.value.messages + Msg("user", q)
        _state.value = _state.value.copy(messages = history, error = null)
        generate(history)
    }

    /** Повторить последний вопрос после ошибки. */
    fun retry() {
        val msgs = _state.value.messages
        if (_state.value.generating || msgs.lastOrNull()?.role != "user") return
        _state.update { it.copy(error = null) }
        generate(msgs)
    }

    private fun generate(history: List<Msg>) {
        val s = settings.current
        if (s.apiKey.isBlank()) {
            _state.update { it.copy(error = "Сначала задайте ключ API в настройках.") }
            return
        }

        stoppedByUser = false
        _state.update {
            it.copy(messages = history + Msg("assistant", ""), generating = true, reasoningChars = 0, error = null)
        }

        val context = buildList {
            if (s.systemPrompt.isNotBlank()) add(Msg("system", s.systemPrompt))
            addAll(history.filter { it.content.isNotBlank() }.takeLast(MAX_CONTEXT).mergeSameRole())
        }

        val id = ++genId
        job = viewModelScope.launch {
            val answer = StringBuilder()
            var reasoning = 0
            try {
                client.stream(
                    apiKey = s.apiKey,
                    model = s.model,
                    thinking = s.thinking,
                    messages = context,
                    onReasoning = { chunk ->
                        reasoning += chunk.length
                        val n = reasoning
                        if (id == genId) _state.update { it.copy(reasoningChars = n) }
                    },
                    onContent = { chunk ->
                        answer.append(chunk)
                        val text = answer.toString()
                        if (id == genId) _state.update { it.copy(messages = it.messages.replaceLast(text)) }
                    },
                )
                if (answer.isBlank() && id == genId) {
                    _state.update { it.copy(error = "Модель вернула пустой ответ.") }
                }
            } catch (e: CancellationException) {
                // нажата «Стоп» — оставляем то, что успело прийти
            } catch (e: Exception) {
                if (!stoppedByUser && id == genId) {
                    val msg = (e as? ApiException)?.message ?: "Ошибка: ${e.message ?: e.javaClass.simpleName}"
                    _state.update { it.copy(error = msg) }
                }
            } finally {
                if (id == genId) {
                    _state.update { st ->
                        val msgs = if (answer.isBlank()) st.messages.dropLastIfEmptyAssistant() else st.messages
                        st.copy(messages = msgs, generating = false)
                    }
                    settings.saveHistory(_state.value.messages)
                }
            }
        }
    }

    fun stop() {
        stoppedByUser = true
        job?.cancel()
        client.cancel()
    }

    fun newChat() {
        stop()
        genId++
        stopSpeaking()
        _state.value = ChatState()
        settings.saveHistory(emptyList())
    }

    fun dismissError() = _state.update { it.copy(error = null) }

    fun showError(text: String) = _state.update { it.copy(error = text) }

    // ---------- озвучивание ответа ----------

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: String? = null
    @Volatile private var lastUtteranceId = ""

    fun speak(text: String) {
        val clean = TextUtil.clean(text)
        if (clean.isBlank()) return
        if (tts == null) {
            pendingSpeech = clean
            tts = TextToSpeech(getApplication()) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsReady = true
                    tts?.setOnUtteranceProgressListener(progressListener)
                    pendingSpeech?.let { doSpeak(it) }
                } else {
                    tts = null
                    showError("Синтез речи на часах недоступен.")
                }
                pendingSpeech = null
            }
        } else if (ttsReady) {
            doSpeak(clean)
        } else {
            pendingSpeech = clean
        }
    }

    private fun doSpeak(text: String) {
        val engine = tts ?: return
        val lang = engine.setLanguage(Locale.forLanguageTag("ru-RU"))
        if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
            showError("Для синтеза речи не установлен русский голос.")
            return
        }
        val chunks = TextUtil.chunksForSpeech(text)
        if (chunks.isEmpty()) return
        val base = System.currentTimeMillis()
        lastUtteranceId = "u$base-${chunks.lastIndex}"
        chunks.forEachIndexed { i, chunk ->
            val mode = if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            engine.speak(chunk, mode, null, "u$base-$i")
        }
        _state.update { it.copy(speaking = true) }
    }

    fun stopSpeaking() {
        tts?.stop()
        _state.update { it.copy(speaking = false) }
    }

    private val progressListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) {
            if (utteranceId == lastUtteranceId) _state.update { it.copy(speaking = false) }
        }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            _state.update { it.copy(speaking = false) }
        }
    }

    override fun onCleared() {
        client.cancel()
        tts?.shutdown()
        tts = null
        super.onCleared()
    }

    companion object {
        /** Сколько последних сообщений отправлять как контекст (экономия токенов). */
        private const val MAX_CONTEXT = 20
    }
}

private fun List<Msg>.replaceLast(content: String): List<Msg> =
    if (isEmpty()) this else dropLast(1) + last().copy(content = content)

private fun List<Msg>.dropLastIfEmptyAssistant(): List<Msg> =
    if (lastOrNull()?.let { it.role == "assistant" && it.content.isBlank() } == true) dropLast(1) else this

/** API не любит два сообщения одной роли подряд (например, после «Стоп») — склеиваем их. */
private fun List<Msg>.mergeSameRole(): List<Msg> {
    val out = mutableListOf<Msg>()
    for (m in this) {
        val prev = out.lastOrNull()
        if (prev != null && prev.role == m.role) {
            out[out.lastIndex] = prev.copy(content = prev.content + "\n\n" + m.content)
        } else {
            out += m
        }
    }
    return out
}
