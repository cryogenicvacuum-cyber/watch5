package io.github.dswatch.ui

import android.app.RemoteInput
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.wear.input.RemoteInputIntentHelper

private const val INPUT_KEY = "text"

/**
 * Системный ввод текста Wear OS: клавиатура, рукописный ввод, голос,
 * а на Galaxy Watch ещё и «Ввод на телефоне».
 * Возвращает функцию, которой передаётся подпись поля.
 */
@Composable
fun rememberTextInput(onResult: (String) -> Unit): (String) -> Unit {
    val callback by rememberUpdatedState(onResult)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data ?: return@rememberLauncherForActivityResult
        val text = RemoteInput.getResultsFromIntent(data)?.getCharSequence(INPUT_KEY)?.toString()
        if (!text.isNullOrBlank()) callback(text)
    }
    return { label ->
        val remoteInput = RemoteInput.Builder(INPUT_KEY).setLabel(label).build()
        val intent = RemoteInputIntentHelper.createActionRemoteInputIntent()
        RemoteInputIntentHelper.putRemoteInputsExtra(intent, listOf(remoteInput))
        launcher.launch(intent)
    }
}

/**
 * Прямое распознавание речи. Если на часах нет службы распознавания,
 * вызывается [onUnavailable] (там открываем обычный ввод — в нём тоже есть микрофон).
 */
@Composable
fun rememberVoiceInput(onResult: (String) -> Unit, onUnavailable: () -> Unit): () -> Unit {
    val callback by rememberUpdatedState(onResult)
    val fallback by rememberUpdatedState(onUnavailable)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!text.isNullOrBlank()) callback(text)
    }
    return {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Спросите DeepSeek")
        }
        try {
            launcher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            fallback()
        }
    }
}
